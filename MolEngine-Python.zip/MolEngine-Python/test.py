# load PythonNET
import sys
import clr

# specify MolEngine DLL folder
sys.path.append(r"C:\Dev\Factory\_Obfuscated")

# load MolEngine DLL
clr.AddReference("Scilligence.MolEngine")
clr.AddReference("Scilligence.MolEngine.Core")
clr.AddReference("Scilligence.MolEngine.Companion")

# use namespace
from Scilligence.MolEngine import *
from Scilligence.MolEngine.Common import *
from Scilligence.MolEngine.Companion import *
from Scilligence.MolEngine.HELM import *

Security.AddLicense("""# Licensed to: TONY(Evaluation)
# Product: DevSuite, Pro
# Modules: openeye.lexichem
# SN: 36c3c43b-ce98-4408-be2c-9a32ee0413f5
# Expiration Date: 2025-Jul-31
MDIwMDAzMDQwMzExMDgx*******************DEwNTE1
""")

HELMMonomerDB.LoadHelmMonomerDB(r"C:\Program Files (x86)\Scilligence\MonomerDBGZEncoded.xml")

m = Molecule.ReadHelm(
    "RNA1{R(A)P.R(G)[sP].R(G)P.[dR](C)P.R(T)P.R(G)P.R(C)P}|RNA2{P.R(G)P.R(A)P.R(A)P.R(U)P.R(U)P.R(A)}|RNA3{R(A)P.R(G)P.R(G)P.R(C)P.R(T)P.R(G)P.R(C)}$RNA1,RNA2,21:R2-17:R2|RNA3,RNA2,1:R1-1:R1$$$V2.0");
notations = Chain.GetComparisonNotation(m)

print(notations[0])